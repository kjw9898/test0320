package com.ezen.koh6.member;

import java.util.ArrayList;

public interface Service {

	int login(String id);

	void insertmember(String id, String pw, String name, String sname, String fname);

	ArrayList<MemberDTO> outa();

	MemberDTO logina(String id, String pw);

	void delete1(String id);
	

}
