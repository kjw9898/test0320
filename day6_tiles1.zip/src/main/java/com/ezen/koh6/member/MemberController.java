package com.ezen.koh6.member;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MemberController {
	ArrayList<MemberDTO>list;
String image_path="C:\\��������Ż12\\spring\\day6_tiles1\\src\\main\\webapp\\image";
	@Autowired
	SqlSession sqlSession;
	@RequestMapping(value = "/memberinput")
	public String kk3() {
		return "memberinput";
	}
	@ResponseBody //
	@RequestMapping(value = "/idcheck2")
	public String kk4(String id) {
	Service ss=sqlSession.getMapper(Service.class);
	int count=	ss.login(id);
	String bigo="";
	if(count==0)
	{
		bigo="ok";
	}
	else
	{
		bigo="no";
	}
		return bigo;
	}//
	
	@RequestMapping(value = "/membersave")//����
	public String kk4(MultipartHttpServletRequest mul) throws IllegalStateException, IOException {		
		String id=mul.getParameter("id");
		String pw=mul.getParameter("pw");
		String name=mul.getParameter("name");
		String sname=mul.getParameter("sname");
		MultipartFile mf=mul.getFile("simage");
		String fname=mf.getOriginalFilename();	
		//����ȭ�Ϲ�ȣ ���� �޼ҵ� ����
		fname=filesave(fname,mf.getBytes());
		
		Service ss=sqlSession.getMapper(Service.class);
		ss.insertmember(id,pw,name,sname,fname);	
		//�̹����� image������ ����...��°���
		mf.transferTo(new File(image_path+"\\"+fname));	
		return "redirect:main";
	}///
	
	private String filesave(String fname, byte[] bytes) throws IOException {
	UUID ud =UUID.randomUUID();
	String sname=ud.toString()+"_"+fname;
	File aa = new File(image_path+sname);
	FileCopyUtils.copy(bytes, aa);
		return sname;
	}
	@RequestMapping(value = "/memberouta")//����
	public ModelAndView kk5(HttpServletRequest request,HttpServletResponse response) throws IOException {
		  HttpSession hs = request.getSession();
	      Boolean flag ; 
	      flag=(Boolean)hs.getAttribute("loginstate");
	      System.out.println(flag);
	      ModelAndView mav = new ModelAndView();
	      if(flag)
	      {
	         Service ss = sqlSession.getMapper(Service.class);
	         ArrayList<MemberDTO>list=ss.outa();
	         System.out.println("ȭ��ũ�� : "+list.size());
	         mav.addObject("list",list);
	         mav.setViewName("memberout");
	         return mav;
	      }
	      else
	      {
	         response.setContentType("text/html;charset=utf-8");
	         PrintWriter pwr = response.getWriter();
	         pwr.print("<script> alert('�α��� �Ŀ� ����ϼ���!');</script>");
	         pwr.print("<script> window.location.href='/koh6/main';</script>");
	         pwr.close();        
	         return null;
	      }
	     
	   
	}///
	@RequestMapping(value = "/login")
	public String kk6() {
		return "loginput";
	}
	@RequestMapping(value = "/loginok",method = RequestMethod.POST)
	public String kk7(HttpServletRequest request) {
		String id=request.getParameter("id");
		String pw=request.getParameter("pw");
		Service ss=sqlSession.getMapper(Service.class);
	MemberDTO dto=	ss.logina(id,pw);
	if(dto!=null)
	{
		HttpSession hs=request.getSession();
		hs.setAttribute("member", dto);
		hs.setAttribute("loginstate", true);
		hs.setMaxInactiveInterval(1800);
		return "redirect:main";
	}else
		
		return "redirect:login";

	}
	
	@RequestMapping(value = "/logout")
	public String kk8(HttpServletRequest request) {
		HttpSession hs = request.getSession();
		hs.removeAttribute("member");
		return "redirect:main";
	}//
	@RequestMapping(value = "/delete1")
	public String kk9(HttpServletRequest request) {
		String id=request.getParameter("id");
		String simage=request.getParameter("simage");
		System.out.println("����ȭ�� : "+simage);
		Service ss=sqlSession.getMapper(Service.class);
		ss.delete1(id);
		File delimg = new File(image_path+"\\"+simage);
		delimg.delete();
		return "redirect:/";
	}//
	
}
