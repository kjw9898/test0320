package com.ezen.hjs6.score;

public class ScoreDTO {
	int hak;
	int ban;
	int bun;
	String name;
	int kor;
	int eng;
	int mat;
	int tot;
	double avg;
	String credit;
	int hakrank;
	int banrank;
	
	int ascore;
	int bscore;
	int cscore;
	int dscore;
	int fscore;
	
	public ScoreDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ScoreDTO(int hak, int ban, int bun, String name, int kor, int eng, int mat, int tot, double avg,
			String credit, int hakrank, int banrank) {
		super();
		this.hak = hak;
		this.ban = ban;
		this.bun = bun;
		this.name = name;
		this.kor = kor;
		this.eng = eng;
		this.mat = mat;
		this.tot = tot;
		this.avg = avg;
		this.credit = credit;
		this.hakrank = hakrank;
		this.banrank = banrank;
	}
	
	public ScoreDTO(int ascore, int bscore, int cscore, int dscore, int fscore) {
		super();
		this.ascore = ascore;
		this.bscore = bscore;
		this.cscore = cscore;
		this.dscore = dscore;
		this.fscore = fscore;
	}

	public int getHak() {
		return hak;
	}

	public void setHak(int hak) {
		this.hak = hak;
	}

	public int getBan() {
		return ban;
	}

	public void setBan(int ban) {
		this.ban = ban;
	}

	public int getBun() {
		return bun;
	}

	public void setBun(int bun) {
		this.bun = bun;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getKor() {
		return kor;
	}

	public void setKor(int kor) {
		this.kor = kor;
	}

	public int getEng() {
		return eng;
	}

	public void setEng(int eng) {
		this.eng = eng;
	}

	public int getMat() {
		return mat;
	}

	public void setMat(int mat) {
		this.mat = mat;
	}

	public int getTot() {
		return tot;
	}

	public void setTot(int tot) {
		this.tot = tot;
	}

	public double getAvg() {
		return avg;
	}

	public void setAvg(double avg) {
		this.avg = avg;
	}

	public String getCredit() {
		return credit;
	}

	public void setCredit(String credit) {
		this.credit = credit;
	}

	public int getHakrank() {
		return hakrank;
	}

	public void setHakrank(int hakrank) {
		this.hakrank = hakrank;
	}

	public int getBanrank() {
		return banrank;
	}

	public void setBanrank(int banrank) {
		this.banrank = banrank;
	}

	public int getAscore() {
		return ascore;
	}

	public void setAscore(int ascore) {
		this.ascore = ascore;
	}

	public int getBscore() {
		return bscore;
	}

	public void setBscore(int bscore) {
		this.bscore = bscore;
	}

	public int getCscore() {
		return cscore;
	}

	public void setCscore(int cscore) {
		this.cscore = cscore;
	}

	public int getDscore() {
		return dscore;
	}

	public void setDscore(int dscore) {
		this.dscore = dscore;
	}

	public int getFscore() {
		return fscore;
	}

	public void setFscore(int fscore) {
		this.fscore = fscore;
	}

	
}
