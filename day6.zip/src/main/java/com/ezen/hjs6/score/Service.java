package com.ezen.hjs6.score;

import java.util.ArrayList;

public interface Service {

	void scoreinput(int hak, int ban, int bun, String name, int kor, int eng, int mat);

	ArrayList<ScoreDTO> scoreout1();

	ArrayList<ScoreDTO> scoreout2();

	ArrayList<ScoreDTO> scoreout3();

	ArrayList<ScoreDTO> scoreout4();

	ArrayList<ScoreDTO> scoreout5();

}
