package com.ezen.hjs6.score;


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller
public class ScoreController {
	@Autowired
	SqlSession sqlSession;
	private static final Logger logger = LoggerFactory.getLogger(ScoreController.class);
	
	@RequestMapping(value = "/scoreinput")
	public String scoreinput() {
		
		return "scoreinput";
	}
	
	@RequestMapping(value = "/scoreout1")
	public String scoreout1(Model mo) {
		Service ss = sqlSession.getMapper(Service.class);
		ArrayList<ScoreDTO> list = ss.scoreout1();
		mo.addAttribute("list", list);
		return "scoreout";
	}

	@RequestMapping(value = "/scoreout2")
	public String scoreout2(Model mo) {
		Service ss = sqlSession.getMapper(Service.class);
		ArrayList<ScoreDTO> list = ss.scoreout2();
		mo.addAttribute("list", list);
		return "scoreout";
	}
	
	@RequestMapping(value = "/scoreout3")
	public String scoreout3(Model mo) {
		Service ss = sqlSession.getMapper(Service.class);
		ArrayList<ScoreDTO> list = ss.scoreout3();
		mo.addAttribute("list", list);
		return "scoreout";
	}
	
	@RequestMapping(value = "/scoreout4")
	public String scoreout4(Model mo) {
		Service ss = sqlSession.getMapper(Service.class);
		ArrayList<ScoreDTO> list = ss.scoreout4();
		int iw = list.size();
		mo.addAttribute("list", list);
		mo.addAttribute("iw", iw);
		return "scoreout4";
	}
	
	@RequestMapping(value = "/scoreout5")
	public String scoreout5(Model mo) {
		Service ss = sqlSession.getMapper(Service.class);
		ArrayList<ScoreDTO> list = ss.scoreout5();
		mo.addAttribute("list", list);
		return "scoreout5";
	}
	
	@RequestMapping(value = "/scoresave", method = RequestMethod.POST)
	public String scoresave(HttpServletRequest request) {
		int hak = Integer.parseInt(request.getParameter("hak"));
		int ban = Integer.parseInt(request.getParameter("ban"));
		int bun = Integer.parseInt(request.getParameter("bun"));
		String name = request.getParameter("name");
		int kor = Integer.parseInt(request.getParameter("kor"));
		int eng = Integer.parseInt(request.getParameter("eng"));
		int mat = Integer.parseInt(request.getParameter("mat"));
		
		Service ss = sqlSession.getMapper(Service.class);
		ss.scoreinput(hak,ban,bun,name,kor,eng,mat);
		return "redirect:/main";
	}
	

}
