package com.ezen.hjs6.member;

import java.util.ArrayList;

public interface Service {

	String checkid(String id);

	void memberinput(String id, String pw, String name, String phone, String address, String pic);

	ArrayList<MemberDTO> memberout();

	MemberDTO login(String id, String pw);

	ArrayList<MemberDTO> deleteAndmodifyView(String id);

	void delete(String id);

	String checkdeleteAndmodify(String id, String pw);

	void modify(String id, String pw, String name, String phone, String address, String pic, String oriid);

}
